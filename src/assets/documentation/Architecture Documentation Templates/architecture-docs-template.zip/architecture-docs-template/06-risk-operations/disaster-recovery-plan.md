# Disaster Recovery / Business Continuity Plan


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Objectives
| Metric | Target |
|---|---|
| RTO (Recovery Time Objective) | |
| RPO (Recovery Point Objective) | |

## 2. Disaster Scenarios Covered
| Scenario | Likelihood | Response Summary |
|---|---|---|
| Region outage | | |
| Data corruption | | |
| Security breach | | |

## 3. Backup Strategy
Frequency, retention, storage location, encryption.

## 4. Recovery Procedures
Step-by-step per scenario (or link to runbooks).

## 5. Roles & Responsibilities During an Incident

## 6. Testing Schedule
How often DR is tested (tabletop / full failover) and last test date.
