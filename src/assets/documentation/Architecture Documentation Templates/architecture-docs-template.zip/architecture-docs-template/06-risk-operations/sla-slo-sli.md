# SLA / SLO / SLI Definitions


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Definitions
- **SLI (Indicator):** the metric being measured
- **SLO (Objective):** internal target for that metric
- **SLA (Agreement):** external commitment, often with penalties

## Table
| Service | SLI | SLO | SLA | Error Budget |
|---|---|---|---|---|
| | Availability | 99.9% | 99.5% | |
| | Latency (p95) | | | |

## Error Budget Policy
What happens when the error budget is exhausted.
