# Risk Register


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


| ID | Risk | Category | Likelihood | Impact | Score | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|---|---|
| R-1 | | Technical/Business/Security/Ops | L/M/H | L/M/H | | | | Open/Mitigated/Closed |

## Risk Scoring Legend
- **Likelihood / Impact:** Low / Medium / High
- **Score:** Likelihood × Impact (or your org's standard formula)

## Review Cadence
How often this register is reviewed and by whom.
