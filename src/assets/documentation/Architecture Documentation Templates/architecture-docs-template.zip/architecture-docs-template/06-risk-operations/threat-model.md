# Threat Model


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Scope
System/component being modeled.

<!-- DIAGRAM: data flow diagram with trust boundaries -->

## 2. Methodology
e.g. STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure,
Denial of Service, Elevation of Privilege).

## 3. Threats Identified
| ID | Component | Threat (STRIDE Category) | Description | Mitigation | Status |
|---|---|---|---|---|---|
| T-1 | | | | | |

## 4. Residual Risk
