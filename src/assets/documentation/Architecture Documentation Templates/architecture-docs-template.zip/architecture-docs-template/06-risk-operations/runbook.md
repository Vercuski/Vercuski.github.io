# Operations Runbook


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Runbook Entry Template
Copy per operational scenario.

### <Scenario, e.g. "API returning 5xx errors">
- **Symptoms:**
- **Likely Causes:**
- **Diagnosis Steps:**
  1.
  2.
- **Resolution Steps:**
  1.
  2.
- **Escalation:** who to page if unresolved in X minutes
- **Related Alerts/Dashboards:**

---

## Runbook Index
| Scenario | Severity | Last Updated |
|---|---|---|
| | | |
