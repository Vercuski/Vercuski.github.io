# ADR-XXXX: <Short Decision Title>

| Field | Value |
|---|---|
| Status | Proposed / Accepted / Deprecated / Superseded by ADR-XXXX |
| Date | YYYY-MM-DD |
| Deciders | |

## Context
What is the issue we're facing? What forces are at play (technical,
business, organizational)?

## Decision
What did we decide?

## Options Considered
| Option | Pros | Cons |
|---|---|---|
| A | | |
| B | | |

## Consequences
### Positive

### Negative / Trade-offs

## Related
Links to related ADRs, SAD sections, or external references.
