# ADR-0001: Record Architecture Decisions

| Field | Value |
|---|---|
| Status | Accepted |
| Date | YYYY-MM-DD |
| Deciders | |

## Context
We need a lightweight, consistent way to capture significant architectural
decisions and the reasoning behind them, so future contributors understand
*why* the system looks the way it does — not just *what* it looks like.

## Decision
We will use Architecture Decision Records (ADRs), stored in
`04-decisions-standards/adr/`, one file per decision, numbered sequentially.
Copy `template.md` for each new decision.

## Consequences
### Positive
- Decisions and their rationale are version-controlled alongside the code.
- New team members can trace *why*, not just *what*.

### Negative / Trade-offs
- Requires discipline to keep up to date.
