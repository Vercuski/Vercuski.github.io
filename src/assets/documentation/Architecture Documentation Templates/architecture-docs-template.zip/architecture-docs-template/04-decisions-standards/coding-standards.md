# Coding Standards / Guidelines


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. General Principles

## 2. Naming Conventions

## 3. Project/Solution Structure

## 4. Error Handling

## 5. Logging Standards

## 6. Testing Standards
Unit/integration/e2e coverage expectations.

## 7. Code Review Checklist
- [ ]
- [ ]

## 8. Linting / Formatting Tools
