# Architecture Principles


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Principle Template
Copy per principle.

### Principle: <Name>
- **Statement:** e.g. "Prefer asynchronous messaging over synchronous calls
  between services."
- **Rationale:**
- **Implications:**
  - What this means in practice
  - What it rules out

---

## Principle Register
| # | Principle | Category |
|---|---|---|
| 1 | | Integration / Data / Security / Ops |
