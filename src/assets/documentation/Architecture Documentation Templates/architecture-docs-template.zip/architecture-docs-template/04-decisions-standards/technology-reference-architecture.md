# Technology / Reference Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Approved Technology Stack
| Category | Approved | Notes |
|---|---|---|
| Language | | |
| Framework | | |
| Database | | |
| Messaging | | |
| Cloud Provider | | |
| CI/CD | | |

## 2. Reference Patterns
Standard patterns approved for reuse (e.g. CQRS, Saga, Event Sourcing,
Strangler Fig) and when to apply them.

| Pattern | When to Use | When Not To |
|---|---|---|
| | | |

## 3. Deprecated / Disallowed Technologies
| Technology | Reason | Replacement |
|---|---|---|
| | | |

## 4. Exception Process
How to request an exception to this reference architecture.
