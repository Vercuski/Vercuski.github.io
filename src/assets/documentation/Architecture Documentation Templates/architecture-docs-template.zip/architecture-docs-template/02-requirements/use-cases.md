# Use Cases / User Stories


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Use Case Template
Copy this block per use case.

### UC-1: <Title>
- **Actor(s):**
- **Preconditions:**
- **Main Flow:**
  1.
  2.
- **Alternate Flows:**
- **Postconditions:**
- **Related NFRs:**

---

## User Story Format (alternative)
> As a <role>, I want <capability>, so that <benefit>.

**Acceptance Criteria (Given/When/Then):**
- Given ..., when ..., then ...
