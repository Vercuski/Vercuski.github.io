# Non-Functional Requirements (NFRs)


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Performance
| Metric | Target | Notes |
|---|---|---|
| p95 latency | | |
| Throughput | | |

## 2. Scalability
- Expected growth (users, data, traffic)
- Horizontal vs vertical scaling strategy

## 3. Availability
| Metric | Target |
|---|---|
| Uptime SLA | e.g. 99.9% |
| RTO | |
| RPO | |

## 4. Security
- AuthN/AuthZ requirements
- Data classification & encryption requirements
- Compliance (SOC2, GDPR, HIPAA, etc.)

## 5. Maintainability
- Code quality gates
- Documentation standards

## 6. Observability
- Logging, metrics, tracing requirements

## 7. Other Quality Attributes
Usability, portability, interoperability, cost efficiency, etc.
