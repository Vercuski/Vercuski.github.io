# Compliance Matrix


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Applicable Standards/Regulations
| Standard | Applicability | Owner |
|---|---|---|
| SOC 2 | | |
| GDPR | | |
| HIPAA | | |

## Control Mapping
| Requirement | Control Description | Implementation | Evidence Location | Status |
|---|---|---|---|---|
| | | | | Compliant / Gap / N-A |

## Open Gaps
| Gap | Risk | Remediation Plan | Target Date |
|---|---|---|---|
| | | | |
