# Architecture Governance Framework


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Purpose

## 2. Roles & Responsibilities
| Role | Responsibility |
|---|---|
| Architecture Review Board (ARB) | |
| Solution Architect | |
| Engineering Lead | |

## 3. Review Process
1. Submit RFC (see `rfc-template.md`)
2. ARB review
3. Decision & ADR recorded

## 4. Escalation Path

## 5. Cadence
Review board meeting frequency, standing agenda.
