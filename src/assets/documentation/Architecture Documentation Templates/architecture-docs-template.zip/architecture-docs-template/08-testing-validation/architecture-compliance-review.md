# Architecture Compliance Review


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Scope of Review

## 2. Compliance Checklist
| Item | Compliant? | Notes |
|---|---|---|
| Follows approved reference architecture | Y/N | |
| ADRs recorded for major decisions | Y/N | |
| NFRs validated | Y/N | |
| Security review completed | Y/N | |

## 3. Findings
| Finding | Severity | Recommendation | Owner |
|---|---|---|---|
| | | | |

## 4. Sign-off
