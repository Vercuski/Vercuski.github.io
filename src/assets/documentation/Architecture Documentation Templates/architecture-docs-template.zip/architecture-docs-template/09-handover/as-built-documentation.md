# As-Built Documentation


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Summary
What was actually deployed — this document should reflect reality, which
often diverges from the original SAD.

## 2. Final Architecture
<!-- DIAGRAM: as-built architecture diagram -->

## 3. Deviations from Original Design
| Planned | Actual | Reason |
|---|---|---|
| | | |

## 4. Environment Details
| Environment | URL | Notes |
|---|---|---|
| Production | | |
| Staging | | |

## 5. Key Configuration
Non-secret configuration values, feature flags, etc.

## 6. Known Issues / Technical Debt
