# Transition Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Purpose
Describes interim architecture state(s) between current and target
(TOGAF Phases E/F equivalent) — useful when migration happens in waves and
the system must remain operational throughout.

## Transition State N: <Name>

<!-- DIAGRAM: interim architecture diagram -->

- **Timeframe:**
- **What's changed from previous state:**
- **Temporary components/bridges:**
- **Exit criteria (what triggers the next transition):**

Repeat per transition state.
