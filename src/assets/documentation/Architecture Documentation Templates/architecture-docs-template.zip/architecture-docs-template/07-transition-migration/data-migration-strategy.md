# Data Migration Strategy


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Data Sources & Targets
| Source | Target | Volume | Sensitivity |
|---|---|---|---|
| | | | |

## 2. Migration Approach
ETL/ELT, tooling, one-time vs continuous sync.

## 3. Data Validation & Reconciliation
How correctness is verified post-migration.

## 4. Downtime / Cutover Window

## 5. Rollback Plan

## 6. PII / Compliance Considerations
