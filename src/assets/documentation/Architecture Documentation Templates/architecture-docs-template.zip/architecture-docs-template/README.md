# Software / Solution Architecture Documentation Template

A ready-to-use folder structure and starter templates for documenting a
software or solution architecture project. Copy this repo, delete what you
don't need, and fill in the rest.

## How to use this repo

1. **Scale to your project.** A small internal tool might only need
   `03-core-architecture/solution-architecture-document.md`, a couple of
   `04-decisions-standards/adr/` entries, and a deployment diagram. A large
   enterprise migration will touch nearly every folder.
2. **Delete, don't leave blank.** Empty templates rot. If a doc doesn't apply,
   remove it rather than committing a stub nobody fills in.
3. **ADRs are the highest-leverage artifact per unit of effort.** They capture
   *why* a decision was made — something diagrams and specs can't. When in
   doubt, write an ADR.
4. **Diagrams as code.** Where possible, keep diagrams in text form
   (Mermaid, PlantUML, Structurizr DSL) alongside these docs so they live in
   version control and diff cleanly. Placeholders for diagrams are marked
   with `<!-- DIAGRAM -->` comments.

## Folder structure

```
architecture-docs-template/
├── 01-strategic/              Vision, business case, roadmap
├── 02-requirements/           BRD, FRS, NFRs, use cases
├── 03-core-architecture/      SAD, C4 diagrams, data/integration/security/network architecture
├── 04-decisions-standards/    ADRs, principles, reference architecture, coding standards
├── 05-governance/             Governance framework, RFCs, ARB minutes, compliance matrix
├── 06-risk-operations/        Risk register, threat model, DR/BCP, capacity, runbooks, SLAs
├── 07-transition-migration/   Gap analysis, migration plan, transition architecture
├── 08-testing-validation/     Test strategy, architecture compliance reviews
└── 09-handover/               As-built docs, onboarding / knowledge transfer
```

## Mapping to common frameworks

- **TOGAF ADM**: `01-strategic` ≈ Phase A · `02-requirements` + `03-core-architecture`
  ≈ Phases B/C/D · `07-transition-migration` ≈ Phases E/F · `05-governance` ≈ Phase G.
- **arc42**: most of `03-core-architecture` and `04-decisions-standards` can be
  collapsed into a single arc42-structured document if you prefer one file
  over many.
- **C4 Model**: see `03-core-architecture/c4-model/` for Context, Container,
  and Component level templates.

## Suggested minimal set (small/medium project)

- `03-core-architecture/solution-architecture-document.md`
- `03-core-architecture/c4-model/context-diagram.md` + `container-diagram.md`
- `04-decisions-standards/adr/template.md` (copy per decision)
- `06-risk-operations/risk-register.md`
- `09-handover/as-built-documentation.md`
