# C4 Model — Level 1: System Context


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Purpose
Shows the system as a single black box and its relationships to users and
other systems.

<!-- DIAGRAM: system context diagram (people, external systems, the system itself) -->

## Actors & External Systems
| Name | Type (Person/System) | Relationship / Description |
|---|---|---|
| | | |

## Notes
Keep this diagram understandable to non-technical stakeholders — no
technology detail belongs here.
