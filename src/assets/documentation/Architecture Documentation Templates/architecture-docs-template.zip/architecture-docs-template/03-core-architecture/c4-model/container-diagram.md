# C4 Model — Level 2: Container Diagram


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Purpose
Zooms into the system to show the high-level technical building blocks
(applications, data stores, microservices) and how they communicate.

<!-- DIAGRAM: container diagram -->

## Containers
| Container | Technology | Responsibility |
|---|---|---|
| Web App | | |
| API | | |
| Database | | |
| Message Broker | | |

## Communication
| From | To | Protocol | Description |
|---|---|---|---|
| | | | |
