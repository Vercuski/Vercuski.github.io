# C4 Model — Level 3: Component Diagram


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## Purpose
Zooms into a single container to show its internal components and their
interactions. Repeat this template per significant container.

## Container: <Name>

<!-- DIAGRAM: component diagram for this container -->

## Components
| Component | Responsibility | Depends On |
|---|---|---|
| | | |

## Key Interactions
<!-- DIAGRAM: sequence diagram for the primary flow(s) through this container -->
