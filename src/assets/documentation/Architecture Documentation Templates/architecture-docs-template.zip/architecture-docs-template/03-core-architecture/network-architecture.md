# Network Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Overview
<!-- DIAGRAM: network topology diagram -->

## 2. Network Zones
| Zone | Purpose | Access Rules |
|---|---|---|
| Public | | |
| DMZ | | |
| Private | | |

## 3. Connectivity
VPN, peering, VPC/VNet design, subnetting.

## 4. Load Balancing & Traffic Management

## 5. DNS Strategy

## 6. Firewall / Security Group Rules Summary
