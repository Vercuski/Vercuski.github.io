# Integration Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Integration Overview
<!-- DIAGRAM: integration landscape diagram -->

## 2. Integration Patterns Used
Sync/async, request-response, pub/sub, event-driven, batch, etc. — and why.

## 3. API Inventory
| API | Type (REST/GraphQL/gRPC) | Consumer(s) | Spec Location |
|---|---|---|---|
| | | | e.g. `openapi.yaml` |

## 4. Message/Event Contracts
| Event/Message | Producer | Consumer(s) | Schema Location |
|---|---|---|---|
| | | | |

## 5. Error Handling & Retry Strategy

## 6. Versioning Strategy

## 7. Third-Party Integrations
| System | Purpose | Auth Method | SLA |
|---|---|---|---|
| | | | |
