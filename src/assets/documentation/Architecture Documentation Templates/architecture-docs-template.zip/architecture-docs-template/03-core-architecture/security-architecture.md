# Security Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Security Principles
Least privilege, defense in depth, zero trust, etc. — state which apply.

## 2. Authentication & Authorization
- AuthN mechanism (OAuth2/OIDC/SAML/etc.)
- AuthZ model (RBAC/ABAC)

<!-- DIAGRAM: auth flow sequence diagram -->

## 3. Trust Boundaries
<!-- DIAGRAM: trust boundary / zone diagram -->

## 4. Data Protection
- Encryption at rest
- Encryption in transit
- Key management

## 5. Threat Model Summary
Full detail in `06-risk-operations/threat-model.md`.

## 6. Secrets Management

## 7. Audit & Logging

## 8. Compliance Requirements
See `05-governance/compliance-matrix.md`.
