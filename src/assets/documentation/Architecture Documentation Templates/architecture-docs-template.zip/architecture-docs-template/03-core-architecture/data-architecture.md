# Data Architecture


| Field | Value |
|---|---|
| Status | Draft / In Review / Approved |
| Owner | |
| Version | 0.1 |
| Last Updated | YYYY-MM-DD |
| Reviewers | |


## 1. Conceptual Data Model
<!-- DIAGRAM: entity relationship diagram (conceptual) -->

## 2. Logical Data Model
<!-- DIAGRAM: ERD (logical, with attributes/keys) -->

## 3. Data Dictionary
| Entity | Attribute | Type | Description | PII? |
|---|---|---|---|---|
| | | | | |

## 4. Data Flow
<!-- DIAGRAM: data flow diagram across systems -->

## 5. Data Storage Strategy
| Data Type | Store | Retention | Backup Strategy |
|---|---|---|---|
| | | | |

## 6. Data Governance
Ownership, quality rules, master data management.

## 7. Data Classification & Privacy
Sensitivity levels, PII handling, anonymization/pseudonymization approach.
